var nelya;
var nelya1;
function zhan() {var z=parseInt(document.getElementById("z").value);var mapOptions = {zoom: z,center: new google.maps.LatLng(parseFloat(document.getElementById("eni").value), parseFloat(document.getElementById("uzundyk").value))};
map = new google.maps.Map(document.getElementById('map'),mapOptions);
var image1 = {url:'img/icon2.png',anchor: new google.maps.Point(30,25)  }
m1 = new google.maps.Marker({map: map,icon: image1,position: new google.maps.LatLng(parseFloat(document.getElementById("eni").value), parseFloat(document.getElementById("uzundyk").value)) });}
function calcRoute() {zhan();
var x1 = parseFloat(document.getElementById("eni").value);var y1 = parseFloat(document.getElementById("uzundyk").value);
var sp = new google.maps.LatLng(eni, uzundyk);
polyline.setMap(map);}google.maps.event.addDomListener(window, 'load', zhan);