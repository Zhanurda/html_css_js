var office  = 'images/iconMarker.png';
var newoffice  = 'images/iconNew.png';
var contentData;
var worldOffices = [
['London', 51.510165, -0.135173, 4, office,contentData],
['New York', 40.760375, -73.972754, 5, office,contentData],
['Paris', 48.873327, 2.297117, 3, office,contentData],
['Moscow', 55.76947, 37.59707, 2, office,contentData],
['Singapore', 1.301155, 103.85453, 1, office,contentData],
['Taraz', 42.895601, 71.367842, 11,newoffice,contentData]
];

var map = new google.maps.Map(document.getElementById('map'), {
zoom: 3,
center: new google.maps.LatLng(30, 20),
mapTypeId: google.maps.MapTypeId.ROADMAP
});

var infowindow = new google.maps.InfoWindow();

var marker, i, contentData;

for (i = 0; i < worldOffices.length; i++) { 
worldOffices[i][5] = ('<div style="width: 150px;">'+('<strong>' + worldOffices[i][0] + '</strong><p>' + worldOffices[i][1] + '° Latitude <br>' + worldOffices[i][2] + '° Longitude</p>')+'</div>');
marker = new google.maps.Marker({
position: new google.maps.LatLng(worldOffices[i][1], worldOffices[i][2]),
map: map,
title:worldOffices[i][0],
icon: worldOffices[i][4],
content:worldOffices[i][5],
});

google.maps.event.addListener(marker, 'click', (function(marker, i) {
return function() {
infowindow.setContent(worldOffices[i][5]);
infowindow.open(map, marker);
}
})(marker, i));
}




