var marker1;
var marker2;
var marker3;
var marker4;
var marker = [
    ['Cancun', 21.161789, -86.855151, contentData]
    ['Guadlajara', 20.659015, -103.352923, contentData]
    ['Mexico City', 21.161789, -86.855151, contentData]
    ['Cancun', 21.161789, -86.855151, contentData]
]
var map;
function initialize() {
var mapOptions = {
zoom: 5,
center: new google.maps.LatLng(18.5, -96),
mapTypeId:google.maps.MapTypeId.TERRAIN
};


map = new google.maps.Map(document.getElementById('map-canvas'),
mapOptions);

marker1 = new google.maps.Marker({
position: new google.maps.LatLng(21.161789, -86.855151) ,
map: map,
icon: {url: "images/icon1.png",
anchor:new google.maps.Point(18, 18)},
title:"Cancun"
});

marker1.setMap(map);

//marker2
marker2 = new google.maps.Marker({
position:new google.maps.LatLng(20.659015, -103.352923),
map: map,
icon :{ url:"images/icon2.png",
anchor:new google.maps.Point(18, 18)},
title:"Guadalajara"
});
marker2.setMap(map);


marker3 = new google.maps.Marker({
position:new google.maps.LatLng(19.432160, -99.147378),
map: map,
icon :{ url: "images/icon3.png",
anchor:new google.maps.Point(18, 18)},
title:"Mexico City"
});
marker3.setMap(map);

marker4 = new google.maps.Marker({
position: new google.maps.LatLng(22.232839, -97.863160),
map: map,
icon: {url:  "images/icon4.png",
anchor:new google.maps.Point(18, 18)},
title:"Tampico"
});
marker4.setMap(map);

}

function calcRoute() {
    var start = document.getElementById('start').value;
    var startComma = start.indexOf(',');
    var startLat = parseFloat(start.substring(0, startComma));
    var startLong = parseFloat(start.substring(startComma + 1, start.length));
    var startPoint = new google.maps.LatLng(startLat, startLong);

    var end = document.getElementById('end').value;
    var endComma = end.indexOf(',');
    var endLat = parseFloat(end.substring(0, endComma));
    var endLong = parseFloat(end.substring(endComma + 1, end.length));
    var endPoint = new google.maps.LatLng(endLat, endLong);

	  var flightPlanCoordinates = [startPoint, endPoint];
	var flightPath = new google.maps.Polyline({
    path: flightPlanCoordinates,
    geodesic: true,
    strokeColor: '#fff',
    strokeOpacity: 1.0,
    strokeWeight: 2
  });

  flightPath.setMap(map);

    function calcDistance(){
        return Math.round(google.maps.geometry.spherical.computeDistanceBetween(startPoint, endPoint) / 1000);
    }
    document.getElementById("calcDistanceOutput").innerHTML = (calcDistance()) + ' km';
}
for (i = 0; i < worldOffices.length; i++) { 
worldOffices[i][5] = ('<div style="width: 150px;">'+('<strong>' + worldOffices[i][0] + '</strong><p>' + worldOffices[i][1] + '° Latitude <br>' + worldOffices[i][2] + '° Longitude</p>')+'</div>');
marker = new google.maps.Marker({
position: new google.maps.LatLng(worldOffices[i][1], worldOffices[i][2]),
map: map,
title:worldOffices[i][0],
icon: worldOffices[i][4],
content:worldOffices[i][5],
});

google.maps.event.addListener(marker, 'click', (function(marker, i) {
return function() {
infowindow.setContent(worldOffices[i][5]);
infowindow.open(map, marker);
}
})(marker, i));
}

google.maps.event.addDomListener(window, 'load', initialize);