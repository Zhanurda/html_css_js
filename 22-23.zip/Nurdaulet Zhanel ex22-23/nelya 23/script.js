//Write your javascript here


function CalculateBMI(feet, inches, pounds, resultElementName) {
	inches = Number(inches)
	pounds = Number(pounds)
	feet = Number(feet)
	var totalInches = (feet * 12 ) + inches
	var resultElement = document.getElementById(resultElementName)
	resultElement.innerHTML =
		Math.round(pounds * 703 * 10 / totalInches / totalInches) / 10
	}
