 function initialize() {
        var myLatlng1 = new google.maps.LatLng(40.760375, -73.972754);
        var mapOptions = {
            zoom : 12,
            center : myLatlng1
        };

        var map = new google.maps.Map(document.getElementById('map-canvas'),
                mapOptions);

        var contentString1 = 'Parallax Global � New York Office'

        var infowindow = new google.maps.InfoWindow({});
		
		
        var marker1 = new google.maps.Marker({
            position : myLatlng1,
            map : map,
			icon:'images/iconMarker.png',
			anchor: new google.maps.Point(10, 10),
			 draggable: true,
			animation: google.maps.Animation.DROP,
            title : 'Parallax Global � New York Office'
        });
     marker1.addListener('click', toggleBounce);
	 
	 function toggleBounce() {
  if (marker1.getAnimation() !== null) {
    marker1.setAnimation(null);
  } else {
    marker1.setAnimation(google.maps.Animation.BOUNCE);
  }
}
	 
        google.maps.event.addListener(marker1, 'click', function initialize() {
			
            infowindow.close();//hide the infowindow
            infowindow.setContent(contentString1);//update the content for this marker
            infowindow.open(map, marker1);

        });
    }

    google.maps.event.addDomListener(window, 'load', initialize);