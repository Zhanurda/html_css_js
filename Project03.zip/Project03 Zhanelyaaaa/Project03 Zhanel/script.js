﻿$(document).ready(function () {
 $(".current").removeAttr('title');

    $(window).scroll(function () {
        var y = $(window).scrollTop();

        if (y > 15) {
            $("header").css({
                "width": "auto",
                "border-top": "none",
                "position": "fixed",
               "z-index": "1",
                "transition": "all .5s linear"
            });
            $("nav").css({
                "height": "26px",
                "box-shadow": "0 2px 10px #666",
                "top": "0",
                 "background-color":"white",
                "z-index": "-1"


            });
            $(".logo").css({
                "background": "url('images/parallaxLogoSm.png') no-repeat",
                "top": "5px",
                "left": "15px",
                "width": "262px",
                "transition": "all .1s linear"

            });

        } else {
            $("header").css({
                "width": "100%",
                "border-top": "11px solid #ef3e36",
                "position": "relative",
                "transition": "all .25s linear"
            });
            $("nav").css({
                "height": "150px",
                "box-shadow": "none",
                "background": "none"
            });
            $(".logo").css({
                "background": "url('images/parallaxLogo.png') no-repeat",
                "top": "21px",
                "left": "57px",
                "width": "234px"
            });
        }
    });
});
