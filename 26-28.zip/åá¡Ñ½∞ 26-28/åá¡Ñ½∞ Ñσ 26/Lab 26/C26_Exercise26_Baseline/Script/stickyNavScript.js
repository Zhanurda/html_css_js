$(document).ready(function(){
	$(".current").removeAttr('title');
	$(".current1").removeAttr('title');
	$(window).scroll(function() {
		var y = $(document).scrollTop();
		if (y > 10) { 
			$("header").css( {"height": "29", "border-top": "none", "position": "fixed", "top": "0","box-shadow": "0 2px 10px #666"} );
			$(".logo").css ( {"background": "url('images/icarnegieLogoSm.png') no-repeat", "top": "8px","left": "10px"});
			$("nav").css   ( {"background": "none"});
		} else {
			$(".logo").css ( {"background":"url('images/icarnegieLogo.png') no-repeat","top": "49px","left": "57px"});
			$("header").css( {"transition": "all .5s linear","width": "100%","height":"190px","border-top":"11px solid #82c54e","position":"relative"});
            $("nav").css   ( {"background": "#eee","position": "absolute","left": "0","bottom": "0", "background-color":"#2f4054","overflow": "auto" });       
		}
	} ); 
});