var map;
var startLat = 25.733685;
var startLng = -100.324197;
var endLat = 21.163070;
var endLng = -86.854121;

var startpoint = {
    url: 'images/icon1.png',
    anchor: new google.maps.Point(18, 18)
};
var endpoint = {
    url: 'images/icon2.png',
    anchor: new google.maps.Point(18, 18)
};

var sites = [
    ["Monterrey", startLat, startLng, startpoint],
    ["Cancun", endLat, endLng, endpoint]
];
function setMarkers(map, locations) {
    for (var i = 0; i < locations.length; i++) {
        var p = locations[i];
        var myLatLng = new google.maps.LatLng(p[1], p[2]);

        var marker = new google.maps.Marker({
            position: myLatLng,
            map: map,
            title: p[0],
            icon: p[3]
        });
    }
}

function initialize() {
    var center = new google.maps.LatLng(22, -97);
    var mapOptions = {
        zoom: 5,
        center: center
    }
    map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
    setMarkers(map, sites);
}

function calcRoute() {
    var startPoint = new google.maps.LatLng(startLat, startLng);
    var endPoint = new google.maps.LatLng(endLat, endLng);

    function calcDistance(){
        return Math.round(google.maps.geometry.spherical.computeDistanceBetween(startPoint, endPoint) / 1000);
    }

    document.getElementById("calcDistanceOutput").innerHTML = "Distance: "+(calcDistance(startPoint, endPoint)) + ' km';
    //(calcDistance(startPoint, endPoint)) + ' km';

    var route = [startPoint, endPoint];

    var polyline = new google.maps.Polyline({
        path: route,
        strokeColor: "#fff"
    });

    polyline.setMap(map);

}

google.maps.event.addDomListener(window, 'load', initialize);
9999999999999