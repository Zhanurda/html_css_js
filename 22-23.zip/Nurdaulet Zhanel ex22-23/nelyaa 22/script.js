//Please write three different blocks of code below. You can write anything you like as long as you use the items we have learned so far — popup boxes, variables, functions, a mathematical operator, strings, and numbers, if else statements, arrays, for loops, and mathematical methods.

//Below is an example of something you can write:
//var number = Math.round((Math.random()*10)+1);
//var guess = prompt("Guess a number between 1 and 10.\nIf you guess the correct number you win.");
   // if (guess == number) {
    //    alert("Congratulations! You win!");
  //  } else {
    //    alert("You guessed number " + guess + ", but the correct number was " + number + ".\nSorry you lose!" )
  //  }

alert("ДОБРО ПОЖАЛОВАТЬ!");
confirm("Ну что, поехали?")

