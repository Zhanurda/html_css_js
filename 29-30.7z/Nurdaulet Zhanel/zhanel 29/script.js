var map;
var marker;
var image1 = 'images/iconMarker.png';
var image2 = 'images/iconDrag.png';

function initialize() {
    var mapOptions = {
            zoom: 3,
	        center: new google.maps.LatLng(47.970718, 67.498318)
        };
    map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
    setMarkers(map, cityes);
}
  
var cityes = [
    ['London', 51.510165, -0.135173, false,image1],
    ['New York ', 40.760375, -73.972754, false, image1],
    ['Paris ', 48.873327, 2.297117, false, image1],
	['Moscow', 55.769469, 37.597066,false,image1],	
	['Singapore',1.301155, 103.854528,false,image1],	
	['Parallax Global — World Offices',34,-41,true,image2],
    
];
									 
function setMarkers(map, locations) {
	
    var image = {url: 'images/iconDrag.png'};
    var image1 = {url: 'images/iconMarker.png'};
			
	
    for (var i = 0; i < locations.length; i++) {
          var city = locations[i];
          var myLatLng = new google.maps.LatLng(city[1],city[2]);
   
	 var marker = new google.maps.Marker({
		  map:map,
    	  draggable:city[3],
    	  position: myLatLng,
    	  icon: city[4],
          title: city[0]
        });
         google.maps.event.addListener(marker, 'click', toggleBounce);
        function toggleBounce() {
  if (marker.getAnimation() !== null) {
    marker.setAnimation(this.null);
  } else {
    marker.setAnimation(google.maps.Animation.BOUNCE);
  }
}
	}
        
};


google.maps.event.addDomListener(window, 'load', initialize);